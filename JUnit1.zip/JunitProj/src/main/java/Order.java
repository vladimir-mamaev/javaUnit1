public enum Order {
    ASC, REVERSE;
}
