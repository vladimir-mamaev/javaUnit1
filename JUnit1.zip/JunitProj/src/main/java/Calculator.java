public class Calculator {
    public  int  getSum(int a,int b){

        return  a+b;
    }
    public int getMultiplex(int a,int b){
        return a*b;
    }
}
